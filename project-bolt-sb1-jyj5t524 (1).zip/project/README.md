# Islamic School Management System

A comprehensive web-based management system designed specifically for Islamic educational institutions.

## 🌟 Features

### 📚 **Student Management**
- Complete student profiles with guardian information
- Guardian contact details and emergency contacts
- Student enrollment tracking and class assignments
- Advanced search and filtering capabilities
- PDF export and print functionality

### 💰 **Financial Management**
- **Expenses Tracking**: Rent bills, WiFi bills, staff salaries, cleaning expenses
- **Fee Management**: Tuition fees, registration fees, activity fees
- Payment status tracking with overdue notifications
- Financial summaries and reporting
- Multiple payment methods support

### 🏫 **Academic Management**
- **Class Management**: Teacher assignments, capacity tracking, subject management
- **Timetable System**: Weekly schedules, subject allocation, teacher assignments
- **Exam Management**: Exam scheduling, duration tracking, teacher assignments
- **Attendance System**: Present/Absent/Late tracking with time logging

### 🛒 **Point of Sale (POS)**
- Product catalog management
- Shopping cart functionality
- Multiple payment methods (Cash, Card, Bank Transfer)
- Receipt generation with PDF export
- Transaction history tracking

### 🔧 **Operations Management**
- **Job Requests**: Maintenance requests, priority tracking, assignment management
- Status tracking (Pending, In Progress, Completed)
- Due date management and notifications

### ⚙️ **System Settings**
- School information management
- Color theme customization with live preview
- User account and password management
- System configuration options

## 🎨 **Design Features**

- **Islamic Theme**: Beautiful emerald green color scheme representing Islamic tradition
- **Professional Interface**: Clean, modern design suitable for educational institutions
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Print-Friendly**: All reports optimized for printing
- **PDF Generation**: Professional PDF exports for all modules
- **Arabic Elements**: Islamic greetings and Quranic verses

## 🔧 **Technical Stack**

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS for responsive design
- **Icons**: Lucide React for consistent iconography
- **PDF Generation**: jsPDF with html2canvas
- **Database**: Supabase (PostgreSQL) for data management
- **Authentication**: Supabase Auth for secure access

## 📊 **Key Statistics & Reports**

- Student enrollment and attendance rates
- Financial summaries (expenses vs. income)
- Class capacity utilization
- Job request completion rates
- Exam scheduling overview
- POS transaction tracking

## 🚀 **Getting Started**

1. **Installation**
   ```bash
   npm install
   ```

2. **Development**
   ```bash
   npm run dev
   ```

3. **Build for Production**
   ```bash
   npm run build
   ```

## 📱 **Responsive Design**

The system is fully responsive and works seamlessly across:
- Desktop computers
- Tablets
- Mobile phones
- Print media

## 🔐 **Security Features**

- Secure user authentication
- Role-based access control
- Data validation and sanitization
- Secure database connections

## 📄 **Export & Print Features**

Every module includes:
- PDF export functionality
- Print-optimized layouts
- Professional report formatting
- School branding integration

## 🌍 **Islamic Features**

- Arabic greetings (Assalamu Alaikum)
- Quranic verses with translations
- Islamic calendar integration ready
- Halal-compliant business practices
- Prayer time considerations

## 📞 **Support**

This system is designed to meet the specific needs of Islamic educational institutions while maintaining modern web standards and user experience best practices.

---

**Built with ❤️ for the Islamic education community**