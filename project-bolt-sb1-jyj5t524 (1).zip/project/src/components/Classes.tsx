import React, { useState } from 'react';
import { Plus, Search, CreditCard as Edit, Trash2, Users, GraduationCap } from 'lucide-react';

interface Class {
  id: string;
  name: string;
  teacherName: string;
  capacity: number;
  currentStudents: number;
  subject: string;
  schedule: string;
}

const Classes: React.FC = () => {
  const [classes, setClasses] = useState<Class[]>([
    {
      id: '1',
      name: 'Grade 1',
      teacherName: 'Ustadh Ahmad Hassan',
      capacity: 25,
      currentStudents: 22,
      subject: 'Islamic Studies & Arabic',
      schedule: 'Mon-Fri 8:00-12:00'
    },
    {
      id: '2',
      name: 'Grade 2',
      teacherName: 'Ustadha Fatima Omar',
      capacity: 25,
      currentStudents: 20,
      subject: 'Quran & Basic Math',
      schedule: 'Mon-Fri 8:00-12:00'
    },
    {
      id: '3',
      name: 'Grade 3',
      teacherName: 'Ustadh Muhammad Ali',
      capacity: 30,
      currentStudents: 28,
      subject: 'Islamic History & Science',
      schedule: 'Mon-Fri 8:00-1:00'
    },
    {
      id: '4',
      name: 'Grade 4',
      teacherName: 'Ustadha Aisha Ibrahim',
      capacity: 30,
      currentStudents: 25,
      subject: 'Advanced Arabic & Math',
      schedule: 'Mon-Fri 8:00-1:00'
    }
  ]);

  const [showModal, setShowModal] = useState(false);
  const [editingClass, setEditingClass] = useState<Class | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    teacherName: '',
    capacity: '',
    subject: '',
    schedule: ''
  });

  const filteredClasses = classes.filter(cls =>
    cls.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cls.teacherName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cls.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingClass) {
      setClasses(classes.map(cls =>
        cls.id === editingClass.id
          ? { 
              ...cls, 
              ...formData, 
              capacity: parseInt(formData.capacity)
            }
          : cls
      ));
    } else {
      const newClass: Class = {
        id: Date.now().toString(),
        ...formData,
        capacity: parseInt(formData.capacity),
        currentStudents: 0
      };
      setClasses([...classes, newClass]);
    }

    setShowModal(false);
    setEditingClass(null);
    setFormData({
      name: '',
      teacherName: '',
      capacity: '',
      subject: '',
      schedule: ''
    });
  };

  const handleEdit = (cls: Class) => {
    setEditingClass(cls);
    setFormData({
      name: cls.name,
      teacherName: cls.teacherName,
      capacity: cls.capacity.toString(),
      subject: cls.subject,
      schedule: cls.schedule
    });
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this class?')) {
      setClasses(classes.filter(cls => cls.id !== id));
    }
  };

  const getCapacityColor = (current: number, capacity: number) => {
    const percentage = (current / capacity) * 100;
    if (percentage >= 90) return 'text-red-600 bg-red-100';
    if (percentage >= 75) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Classes Management</h2>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Class</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Classes</p>
              <p className="text-3xl font-bold text-gray-900">{classes.length}</p>
            </div>
            <GraduationCap className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Students</p>
              <p className="text-3xl font-bold text-gray-900">
                {classes.reduce((sum, cls) => sum + cls.currentStudents, 0)}
              </p>
            </div>
            <Users className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Capacity</p>
              <p className="text-3xl font-bold text-gray-900">
                {Math.round(classes.reduce((sum, cls) => sum + (cls.currentStudents / cls.capacity * 100), 0) / classes.length)}%
              </p>
            </div>
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-purple-600 font-bold">%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search classes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
        />
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.map((cls) => (
          <div key={cls.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{cls.name}</h3>
                <p className="text-sm text-gray-600">{cls.subject}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit(cls)}
                  className="text-blue-600 hover:text-blue-900"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDelete(cls.id)}
                  className="text-red-600 hover:text-red-900"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <GraduationCap className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{cls.teacherName}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Capacity</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCapacityColor(cls.currentStudents, cls.capacity)}`}>
                  {cls.currentStudents}/{cls.capacity}
                </span>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(cls.currentStudents / cls.capacity) * 100}%` }}
                />
              </div>

              <div className="pt-2 border-t border-gray-100">
                <p className="text-xs text-gray-500">Schedule</p>
                <p className="text-sm text-gray-700">{cls.schedule}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {editingClass ? 'Edit Class' : 'Add New Class'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Class Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="e.g., Grade 5"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Class Teacher
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.teacherName}
                    onChange={(e) => setFormData({ ...formData, teacherName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="e.g., Ustadh Ahmad Hassan"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Capacity
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="50"
                    value={formData.capacity}
                    onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="e.g., Islamic Studies & Arabic"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Schedule
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.schedule}
                    onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="e.g., Mon-Fri 8:00-12:00"
                  />
                </div>
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingClass(null);
                      setFormData({
                        name: '',
                        teacherName: '',
                        capacity: '',
                        subject: '',
                        schedule: ''
                      });
                    }}
                    className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    {editingClass ? 'Update' : 'Add'} Class
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Classes;