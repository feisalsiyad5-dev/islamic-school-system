import React from 'react';
import { Users, DollarSign, GraduationCap, Calendar, TrendingUp, BookOpen } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Students',
      value: '245',
      change: '+12%',
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      title: 'Total Classes',
      value: '18',
      change: '+2',
      icon: GraduationCap,
      color: 'bg-emerald-500',
    },
    {
      title: 'Monthly Expenses',
      value: '$12,450',
      change: '-5%',
      icon: DollarSign,
      color: 'bg-red-500',
    },
    {
      title: 'Attendance Rate',
      value: '94.2%',
      change: '+2.1%',
      icon: Calendar,
      color: 'bg-purple-500',
    },
  ];

  const recentActivities = [
    { action: 'New student enrolled', time: '2 hours ago', type: 'success' },
    { action: 'Fee payment received', time: '4 hours ago', type: 'info' },
    { action: 'Exam scheduled for Grade 5', time: '6 hours ago', type: 'warning' },
    { action: 'Monthly expenses updated', time: '1 day ago', type: 'neutral' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-lg p-6 text-white">
        <h2 className="text-3xl font-bold mb-2">Assalamu Alaikum</h2>
        <p className="text-emerald-100">Welcome to the Islamic School Management System</p>
        <div className="mt-4 flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5" />
            <span>Academic Year 2024-2025</span>
          </div>
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5" />
            <span>Semester 1</span>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-600">{stat.change}</span>
                  </div>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activities and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'info' ? 'bg-blue-500' :
                  activity.type === 'warning' ? 'bg-yellow-500' :
                  'bg-gray-400'
                }`} />
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <Users className="w-6 h-6 text-blue-500 mx-auto mb-2" />
              <span className="text-sm font-medium">Add Student</span>
            </button>
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <Calendar className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
              <span className="text-sm font-medium">Mark Attendance</span>
            </button>
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <DollarSign className="w-6 h-6 text-red-500 mx-auto mb-2" />
              <span className="text-sm font-medium">Add Expense</span>
            </button>
            <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <GraduationCap className="w-6 h-6 text-purple-500 mx-auto mb-2" />
              <span className="text-sm font-medium">Create Class</span>
            </button>
          </div>
        </div>
      </div>

      {/* Islamic Quote */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
        <div className="text-2xl text-emerald-600 mb-2">﷽</div>
        <p className="text-lg text-gray-700 italic mb-2">
          "وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا"
        </p>
        <p className="text-md text-gray-600 mb-2">
          "And whoever fears Allah - He will make for him a way out"
        </p>
        <p className="text-sm text-gray-500">Quran 65:2</p>
      </div>
    </div>
  );
};

export default Dashboard;