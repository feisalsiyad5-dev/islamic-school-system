import React, { useState } from 'react';
import { Plus, Minus, ShoppingCart, Printer, Download, Trash2, Calculator } from 'lucide-react';
import { generatePDF, printElement } from '../utils/pdfGenerator';

interface POSItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface Transaction {
  id: string;
  items: POSItem[];
  total: number;
  paymentMethod: string;
  date: string;
  time: string;
}

const POS: React.FC = () => {
  const [availableItems] = useState([
    { id: '1', name: 'School Uniform', price: 25.00 },
    { id: '2', name: 'Islamic Books', price: 15.00 },
    { id: '3', name: 'Prayer Mat', price: 20.00 },
    { id: '4', name: 'Quran', price: 30.00 },
    { id: '5', name: 'School Bag', price: 35.00 },
    { id: '6', name: 'Stationery Set', price: 12.00 },
    { id: '7', name: 'Water Bottle', price: 8.00 },
    { id: '8', name: 'Lunch Box', price: 18.00 }
  ]);

  const [cartItems, setCartItems] = useState<POSItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [showReceipt, setShowReceipt] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null);

  const addToCart = (item: { id: string; name: string; price: number }) => {
    const existingItem = cartItems.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCartItems(cartItems.map(cartItem =>
        cartItem.id === item.id
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCartItems([...cartItems, { ...item, quantity: 1 }]);
    }
  };

  const updateQuantity = (id: string, change: number) => {
    setCartItems(cartItems.map(item => {
      if (item.id === id) {
        const newQuantity = Math.max(0, item.quantity + change);
        return newQuantity === 0 ? null : { ...item, quantity: newQuantity };
      }
      return item;
    }).filter(Boolean) as POSItem[]);
  };

  const removeFromCart = (id: string) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const processPayment = () => {
    if (cartItems.length === 0) return;

    const transaction: Transaction = {
      id: Date.now().toString(),
      items: [...cartItems],
      total: calculateTotal(),
      paymentMethod,
      date: new Date().toLocaleDateString(),
      time: new Date().toLocaleTimeString()
    };

    setTransactions([transaction, ...transactions]);
    setCurrentTransaction(transaction);
    setCartItems([]);
    setShowReceipt(true);
  };

  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Point of Sale (POS)</h2>
        <div className="flex gap-2">
          <button
            onClick={clearCart}
            className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Cart</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Products */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Items</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {availableItems.map((item) => (
                <div key={item.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h4 className="font-medium text-gray-900 mb-2">{item.name}</h4>
                  <p className="text-lg font-bold text-emerald-600 mb-3">${item.price.toFixed(2)}</p>
                  <button
                    onClick={() => addToCart(item)}
                    className="w-full flex items-center justify-center space-x-2 bg-emerald-600 text-white px-3 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Cart</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Cart */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <ShoppingCart className="w-5 h-5 text-emerald-600" />
              <h3 className="text-lg font-semibold text-gray-900">Shopping Cart</h3>
            </div>

            {cartItems.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Cart is empty</p>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between border-b border-gray-100 pb-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.name}</h4>
                      <p className="text-sm text-gray-600">${item.price.toFixed(2)} each</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-1 rounded-full bg-red-100 hover:bg-red-200 text-red-600 ml-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

                <div className="pt-4 border-t border-gray-200">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-lg font-semibold text-gray-900">Total:</span>
                    <span className="text-2xl font-bold text-emerald-600">${calculateTotal().toFixed(2)}</span>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    >
                      <option value="cash">Cash</option>
                      <option value="card">Card</option>
                      <option value="bank_transfer">Bank Transfer</option>
                    </select>
                  </div>

                  <button
                    onClick={processPayment}
                    className="w-full flex items-center justify-center space-x-2 bg-emerald-600 text-white px-4 py-3 rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    <Calculator className="w-5 h-5" />
                    <span>Process Payment</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Recent Transactions */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h3>
            {transactions.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No transactions yet</p>
            ) : (
              <div className="space-y-3">
                {transactions.slice(0, 5).map((transaction) => (
                  <div key={transaction.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">${transaction.total.toFixed(2)}</p>
                      <p className="text-sm text-gray-600">{transaction.date} {transaction.time}</p>
                    </div>
                    <button
                      onClick={() => {
                        setCurrentTransaction(transaction);
                        setShowReceipt(true);
                      }}
                      className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
                    >
                      View Receipt
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Receipt Modal */}
      {showReceipt && currentTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Receipt</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={() => printElement('receipt-content')}
                    className="flex items-center space-x-1 bg-gray-600 text-white px-3 py-1 rounded text-sm hover:bg-gray-700"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print</span>
                  </button>
                  <button
                    onClick={() => generatePDF('receipt-content', `receipt-${currentTransaction.id}.pdf`)}
                    className="flex items-center space-x-1 bg-emerald-600 text-white px-3 py-1 rounded text-sm hover:bg-emerald-700"
                  >
                    <Download className="w-4 h-4" />
                    <span>PDF</span>
                  </button>
                </div>
              </div>

              <div id="receipt-content" className="border border-gray-200 p-6 rounded-lg">
                <div className="text-center mb-6">
                  <h1 className="text-xl font-bold text-emerald-600">Islamic School</h1>
                  <p className="text-sm text-gray-600">Management System</p>
                  <p className="text-sm text-gray-600">Receipt #{currentTransaction.id}</p>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-600">Date: {currentTransaction.date}</p>
                  <p className="text-sm text-gray-600">Time: {currentTransaction.time}</p>
                  <p className="text-sm text-gray-600">Payment: {currentTransaction.paymentMethod.replace('_', ' ').toUpperCase()}</p>
                </div>

                <div className="border-t border-gray-200 pt-4 mb-4">
                  {currentTransaction.items.map((item) => (
                    <div key={item.id} className="flex justify-between items-center mb-2">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-600">${item.price.toFixed(2)} x {item.quantity}</p>
                      </div>
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <div className="flex justify-between items-center">
                    <p className="text-lg font-bold">Total:</p>
                    <p className="text-lg font-bold text-emerald-600">KSH {currentTransaction.total.toFixed(2)}</p>
                  </div>
                </div>

                <div className="text-center mt-6 pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-600">Thank you for your purchase!</p>
                  <p className="text-sm text-gray-600">Barakallahu feeki</p>
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <button
                  onClick={() => setShowReceipt(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default POS;