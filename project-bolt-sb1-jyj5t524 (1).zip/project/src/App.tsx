import React, { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Students from './components/Students';
import Expenses from './components/Expenses';
import Classes from './components/Classes';
import Attendance from './components/Attendance';
import Timetable from './components/Timetable';
import POS from './components/POS';
import JobRequests from './components/JobRequests';
import Exams from './components/Exams';
import Fees from './components/Fees';
import Settings from './components/Settings';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'students':
        return <Students />;
      case 'expenses':
        return <Expenses />;
      case 'classes':
        return <Classes />;
      case 'attendance':
        return <Attendance />;
      case 'timetable':
        return <Timetable />;
      case 'pos':
        return <POS />;
      case 'jobs':
        return <JobRequests />;
      case 'exams':
        return <Exams />;
      case 'fees':
        return <Fees />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout currentPage={currentPage} onPageChange={setCurrentPage}>
      {renderPage()}
    </Layout>
  );
}

export default App;