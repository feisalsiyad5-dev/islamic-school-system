export interface Student {
  id: string;
  name: string;
  age: number;
  class_id: string;
  guardian_name: string;
  guardian_phone: string;
  address: string;
  enrollment_date: string;
  created_at: string;
}

export interface Class {
  id: string;
  name: string;
  teacher_name: string;
  capacity: number;
  created_at: string;
}

export interface Expense {
  id: string;
  type: 'rent' | 'wifi' | 'salary' | 'cleaning' | 'other';
  amount: number;
  description: string;
  date: string;
  created_at: string;
}

export interface Attendance {
  id: string;
  student_id: string;
  class_id: string;
  date: string;
  status: 'present' | 'absent' | 'late';
  time_in?: string;
  created_at: string;
}

export interface Timetable {
  id: string;
  class_id: string;
  day: string;
  subject: string;
  start_time: string;
  end_time: string;
  teacher: string;
  created_at: string;
}

export interface POSItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

export interface POSTransaction {
  id: string;
  items: POSItem[];
  total_amount: number;
  payment_method: string;
  date: string;
  created_at: string;
}

export interface JobRequest {
  id: string;
  title: string;
  description: string;
  requested_by: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed';
  date_requested: string;
  created_at: string;
}

export interface Exam {
  id: string;
  subject: string;
  class_id: string;
  date: string;
  duration: number;
  total_marks: number;
  created_at: string;
}

export interface Fee {
  id: string;
  student_id: string;
  amount: number;
  type: string;
  due_date: string;
  paid: boolean;
  paid_date?: string;
  created_at: string;
}

export interface Settings {
  id: string;
  primary_color: string;
  secondary_color: string;
  school_name: string;
  school_address: string;
  school_phone: string;
  created_at: string;
}